<!DOCTYPE HTML>
<html lang="pl">
    <head>
        <meta charset=""utf-8">
              <title>MEJN PEJDŻ</title>
    </head>
    
    <body>
        <h3>YEEHAW</h3>
        <table style="padding: 10px">
            <th>
            <img src="https://github.com/drakar1903/Technologie-Aplikacji-Serwerowych/blob/master/Logo.png?raw=true">
            </th>
            <th>
                    <form padding: 30px; action="sukces.php" method="post">
                    Yer login: <br/>
                    <input type="text" name="login"/><br/>
                    Yer pass: <br/>
                    <input type="password" name="password"/><br/><br/>
                    <input type="submit" value="Log in, pardner"/>
                    </form>
            </th>
        </table>
    </body>
</html>
